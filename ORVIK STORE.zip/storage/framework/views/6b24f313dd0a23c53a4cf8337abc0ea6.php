<section class="relative overflow-hidden pt-12 pb-24 md:pt-20 md:pb-32 min-h-[92vh] flex flex-col justify-center items-center">
    <!-- Background Video Treatment -->
    <div class="absolute inset-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <video
            autoplay
            loop
            muted
            playsinline
            preload="auto"
            class="absolute inset-0 w-full h-full object-cover opacity-35"
        >
            <source src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260319_015952_e1deeb12-8fb7-4071-a42a-60779fc64ab6.mp4" type="video/mp4">
        </video>
        <!-- Very Subtle Gradient Overlay preserving natural brightness -->
        <div class="absolute inset-0 bg-gradient-to-b from-white/70 via-white/50 to-white/90"></div>
    </div>

    <!-- Hero Content -->
    <div class="relative z-10 mx-auto max-w-7xl px-6 md:px-12 lg:px-20 text-center flex flex-col items-center w-full">
        <!-- Hero Badge -->
        <div class="inline-flex items-center gap-1.5 rounded-full border border-border bg-white/90 px-4 py-1.5 text-sm font-body text-foreground shadow-2xs mb-6 select-none animate-fade-up-1 backdrop-blur-xs">
            <span class="text-accent text-xs">&#10022;</span>
            <span class="font-medium">Simple stall management, built for speed</span>
        </div>

        <!-- Hero Headline (Instrument Serif) -->
        <h1 class="text-center font-display text-5xl md:text-6xl lg:text-[5.25rem] leading-[0.95] tracking-tight max-w-xl text-foreground animate-fade-up-2">
            The <span class="italic font-normal text-accent">Simpler</span> Way to Run Your Stall
        </h1>

        <!-- Hero Subheadline (Inter) -->
        <p class="mt-4 text-center text-base md:text-lg max-w-[650px] leading-relaxed font-body text-muted-foreground animate-fade-up-3">
            Manage sales, inventory, stock levels, and business reports from one simple system built for busy stalls.
        </p>

        <!-- Hero CTA Buttons -->
        <div class="mt-6 flex items-center justify-center gap-3 animate-fade-up-4">
            <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['variant' => 'primary','size' => 'lg','rounded' => 'full','href' => route('register')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'primary','size' => 'lg','rounded' => 'full','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('register'))]); ?>
                Get Started
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['variant' => 'secondary','size' => 'lg','rounded' => 'full','href' => '#how-it-works']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'secondary','size' => 'lg','rounded' => 'full','href' => '#how-it-works']); ?>
                See How It Works
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
        </div>

        <!-- Coded Dashboard Preview Container -->
        <div class="w-full max-w-5xl mt-12 sm:mt-16 animate-fade-up-5">
            <?php if (isset($component)) { $__componentOriginalfac46918187914d83676707b0c20b0d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfac46918187914d83676707b0c20b0d4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.preview','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.preview'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfac46918187914d83676707b0c20b0d4)): ?>
<?php $attributes = $__attributesOriginalfac46918187914d83676707b0c20b0d4; ?>
<?php unset($__attributesOriginalfac46918187914d83676707b0c20b0d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfac46918187914d83676707b0c20b0d4)): ?>
<?php $component = $__componentOriginalfac46918187914d83676707b0c20b0d4; ?>
<?php unset($__componentOriginalfac46918187914d83676707b0c20b0d4); ?>
<?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/landing/components/hero.blade.php ENDPATH**/ ?>