<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Dashboard',
    'subtitle' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Dashboard',
    'subtitle' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $user = auth()->user();
    $business = $user?->currentBusiness();
    $role = $user?->currentRole();
?>

<header class="h-16 border-b border-border bg-white px-4 md:px-8 flex items-center justify-between gap-4 sticky top-0 z-30">
    <!-- Title / Breadcrumb / Stall context -->
    <div class="flex items-center gap-3">
        <!-- Mobile Logo Icon -->
        <div class="lg:hidden">
            <?php if (isset($component)) { $__componentOriginal8641339168305ca7d1df3ab05341c05a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8641339168305ca7d1df3ab05341c05a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.branding.logo','data' => ['size' => 'sm','showText' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('branding.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'sm','showText' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8641339168305ca7d1df3ab05341c05a)): ?>
<?php $attributes = $__attributesOriginal8641339168305ca7d1df3ab05341c05a; ?>
<?php unset($__attributesOriginal8641339168305ca7d1df3ab05341c05a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8641339168305ca7d1df3ab05341c05a)): ?>
<?php $component = $__componentOriginal8641339168305ca7d1df3ab05341c05a; ?>
<?php unset($__componentOriginal8641339168305ca7d1df3ab05341c05a); ?>
<?php endif; ?>
        </div>

        <div>
            <div class="flex items-center gap-2">
                <h1 class="text-lg font-bold tracking-tight text-foreground"><?php echo e($title); ?></h1>
                <?php if($business): ?>
                    <span class="hidden sm:inline-flex text-[11px] px-2 py-0.5 rounded-full bg-secondary border border-border text-foreground font-semibold">
                        <?php echo e($business->name); ?>

                    </span>
                <?php endif; ?>
            </div>
            <?php if($subtitle): ?>
                <p class="text-xs text-muted-foreground hidden sm:block"><?php echo e($subtitle); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Controls -->
    <div class="flex items-center gap-3">
        <?php if($user && $user->hasPermissionTo('sales.create')): ?>
            <!-- Quick POS Button -->
            <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['variant' => 'accent','size' => 'sm','rounded' => 'lg','href' => route('app.sales'),'icon' => 'shopping-cart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'accent','size' => 'sm','rounded' => 'lg','href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('app.sales')),'icon' => 'shopping-cart']); ?>
                <span class="hidden sm:inline">New Sale</span>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
        <?php endif; ?>

        <!-- User Menu Dropdown -->
        <?php if (isset($component)) { $__componentOriginaleea726fa4f84deb9f7684b50bdd6328c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaleea726fa4f84deb9f7684b50bdd6328c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.dropdown','data' => ['align' => 'right','width' => '56']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '56']); ?>
             <?php $__env->slot('trigger', null, []); ?> 
                <button type="button" class="flex items-center gap-2.5 rounded-lg p-1.5 hover:bg-muted transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                    <div class="w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold flex items-center justify-center text-xs">
                        <?php echo e($user ? strtoupper(substr($user->name, 0, 2)) : 'OS'); ?>

                    </div>
                    <div class="text-left hidden md:block">
                        <p class="text-xs font-semibold text-foreground"><?php echo e($user?->name ?? 'Operator'); ?></p>
                        <p class="text-[10px] text-muted-foreground"><?php echo e($role?->display_name ?? 'Staff'); ?></p>
                    </div>
                    <i data-lucide="chevron-down" class="w-3.5 h-3.5 text-muted-foreground"></i>
                </button>
             <?php $__env->endSlot(); ?>

             <?php $__env->slot('content', null, []); ?> 
                <div class="px-4 py-2.5 border-b border-border/70 text-xs">
                    <p class="font-semibold text-foreground"><?php echo e($user?->name); ?></p>
                    <p class="text-muted-foreground truncate"><?php echo e($user?->email); ?></p>
                    <?php if($business): ?>
                        <p class="text-[10px] text-accent font-semibold mt-1">Stall: <?php echo e($business->name); ?></p>
                    <?php endif; ?>
                </div>

                <a href="<?php echo e(route('app.settings.account')); ?>" class="flex items-center gap-2 px-4 py-2 text-xs text-foreground hover:bg-muted transition-colors">
                    <i data-lucide="user" class="w-3.5 h-3.5 text-muted-foreground"></i>
                    <span>Profile & Password</span>
                </a>

                <?php if($user && $user->hasPermissionTo('settings.view')): ?>
                    <a href="<?php echo e(route('app.settings.business')); ?>" class="flex items-center gap-2 px-4 py-2 text-xs text-foreground hover:bg-muted transition-colors">
                        <i data-lucide="store" class="w-3.5 h-3.5 text-muted-foreground"></i>
                        <span>Business Settings</span>
                    </a>
                <?php endif; ?>

                <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2 px-4 py-2 text-xs text-foreground hover:bg-muted transition-colors">
                    <i data-lucide="external-link" class="w-3.5 h-3.5 text-muted-foreground"></i>
                    <span>Marketing Page</span>
                </a>

                <div class="border-t border-border/70 my-1"></div>

                <!-- Secure Logout Form -->
                <form method="POST" action="<?php echo e(route('app.logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full text-left flex items-center gap-2 px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 transition-colors">
                        <i data-lucide="log-out" class="w-3.5 h-3.5"></i>
                        <span>Sign Out</span>
                    </button>
                </form>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaleea726fa4f84deb9f7684b50bdd6328c)): ?>
<?php $attributes = $__attributesOriginaleea726fa4f84deb9f7684b50bdd6328c; ?>
<?php unset($__attributesOriginaleea726fa4f84deb9f7684b50bdd6328c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaleea726fa4f84deb9f7684b50bdd6328c)): ?>
<?php $component = $__componentOriginaleea726fa4f84deb9f7684b50bdd6328c; ?>
<?php unset($__componentOriginaleea726fa4f84deb9f7684b50bdd6328c); ?>
<?php endif; ?>
    </div>
</header>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/navigation/app-header.blade.php ENDPATH**/ ?>