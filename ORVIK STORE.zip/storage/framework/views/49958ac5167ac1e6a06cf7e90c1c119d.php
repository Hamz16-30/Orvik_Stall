<footer class="bg-secondary/40 border-t border-border/80 py-12 md:py-16 text-foreground">
    <div class="mx-auto max-w-7xl px-6 md:px-12 lg:px-20">
        <div class="grid grid-cols-1 md:grid-cols-12 gap-8 pb-12 border-b border-border/60">
            <!-- Brand Column (6 cols) -->
            <div class="md:col-span-6 space-y-3">
                <?php if (isset($component)) { $__componentOriginal8641339168305ca7d1df3ab05341c05a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8641339168305ca7d1df3ab05341c05a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.branding.logo','data' => ['size' => 'lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('branding.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8641339168305ca7d1df3ab05341c05a)): ?>
<?php $attributes = $__attributesOriginal8641339168305ca7d1df3ab05341c05a; ?>
<?php unset($__attributesOriginal8641339168305ca7d1df3ab05341c05a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8641339168305ca7d1df3ab05341c05a)): ?>
<?php $component = $__componentOriginal8641339168305ca7d1df3ab05341c05a; ?>
<?php unset($__componentOriginal8641339168305ca7d1df3ab05341c05a); ?>
<?php endif; ?>
                <p class="text-sm text-muted-foreground max-w-sm">
                    Simple stall management for modern retail. Fast POS, proactive stock alerts, and automated profit reconciliation.
                </p>
            </div>

            <!-- Product Navigation (3 cols) -->
            <div class="md:col-span-3 space-y-3">
                <h4 class="text-xs font-bold uppercase tracking-wider text-foreground">Product</h4>
                <ul class="space-y-2 text-sm text-muted-foreground">
                    <li><a href="#features" class="hover:text-foreground transition-colors">Features</a></li>
                    <li><a href="#how-it-works" class="hover:text-foreground transition-colors">How It Works</a></li>
                    <li><a href="#showcase" class="hover:text-foreground transition-colors">POS & Inventory</a></li>
                    <li><a href="#pricing" class="hover:text-foreground transition-colors">Pricing</a></li>
                </ul>
            </div>

            <!-- Company (3 cols) -->
            <div class="md:col-span-3 space-y-3">
                <h4 class="text-xs font-bold uppercase tracking-wider text-foreground">Company</h4>
                <ul class="space-y-2 text-sm text-muted-foreground">
                    <li><a href="mailto:support@orvikstore.com" class="hover:text-foreground transition-colors">Contact Support</a></li>
                    <li><a href="#" class="hover:text-foreground transition-colors">Privacy Policy</a></li>
                    <li><a href="#" class="hover:text-foreground transition-colors">Terms of Service</a></li>
                </ul>
            </div>
        </div>

        <!-- Bottom Copyright -->
        <div class="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-muted-foreground gap-4">
            <p>&copy; 2026 ORVIK Store. All rights reserved.</p>
            <p class="flex items-center gap-1 text-[11px]">
                <span class="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>All stall services operating normally</span>
            </p>
        </div>
    </div>
</footer>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/landing/components/footer.blade.php ENDPATH**/ ?>