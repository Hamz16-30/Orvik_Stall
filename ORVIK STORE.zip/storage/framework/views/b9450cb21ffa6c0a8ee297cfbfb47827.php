<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Dashboard',
    'subtitle' => null,
    'activeNav' => 'dashboard',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Dashboard',
    'subtitle' => null,
    'activeNav' => 'dashboard',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($title); ?> — <?php echo e(config('app.name', 'ORVIK Store')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Scripts and Styles -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-secondary/30 text-foreground font-body antialiased flex min-h-screen">
    <!-- Desktop Sidebar -->
    <?php if (isset($component)) { $__componentOriginal7025b2d0fe076ff7fcf02a51f111c1c9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7025b2d0fe076ff7fcf02a51f111c1c9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navigation.app-sidebar','data' => ['active' => $activeNav]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation.app-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activeNav)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7025b2d0fe076ff7fcf02a51f111c1c9)): ?>
<?php $attributes = $__attributesOriginal7025b2d0fe076ff7fcf02a51f111c1c9; ?>
<?php unset($__attributesOriginal7025b2d0fe076ff7fcf02a51f111c1c9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7025b2d0fe076ff7fcf02a51f111c1c9)): ?>
<?php $component = $__componentOriginal7025b2d0fe076ff7fcf02a51f111c1c9; ?>
<?php unset($__componentOriginal7025b2d0fe076ff7fcf02a51f111c1c9); ?>
<?php endif; ?>

    <!-- Main Application Column -->
    <div class="flex-1 flex flex-col min-w-0 pb-20 lg:pb-8">
        <!-- Top App Header -->
        <?php if (isset($component)) { $__componentOriginal4dbdd862fd3cc568e5e60814338b3704 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4dbdd862fd3cc568e5e60814338b3704 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navigation.app-header','data' => ['title' => $title,'subtitle' => $subtitle]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation.app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title),'subtitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($subtitle)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4dbdd862fd3cc568e5e60814338b3704)): ?>
<?php $attributes = $__attributesOriginal4dbdd862fd3cc568e5e60814338b3704; ?>
<?php unset($__attributesOriginal4dbdd862fd3cc568e5e60814338b3704); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4dbdd862fd3cc568e5e60814338b3704)): ?>
<?php $component = $__componentOriginal4dbdd862fd3cc568e5e60814338b3704; ?>
<?php unset($__componentOriginal4dbdd862fd3cc568e5e60814338b3704); ?>
<?php endif; ?>

        <!-- Main Content Area -->
        <main class="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
            <?php echo e($slot); ?>

        </main>
    </div>

    <!-- Mobile Bottom Navigation -->
    <?php if (isset($component)) { $__componentOriginald24c425876d89aaa366ce382b1293340 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald24c425876d89aaa366ce382b1293340 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navigation.mobile-nav','data' => ['active' => $activeNav]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation.mobile-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($activeNav)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald24c425876d89aaa366ce382b1293340)): ?>
<?php $attributes = $__attributesOriginald24c425876d89aaa366ce382b1293340; ?>
<?php unset($__attributesOriginald24c425876d89aaa366ce382b1293340); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald24c425876d89aaa366ce382b1293340)): ?>
<?php $component = $__componentOriginald24c425876d89aaa366ce382b1293340; ?>
<?php unset($__componentOriginald24c425876d89aaa366ce382b1293340); ?>
<?php endif; ?>

    <!-- Global Toast Notifications -->
    <?php if (isset($component)) { $__componentOriginal339c7fedf680433726dbafc2f156956f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal339c7fedf680433726dbafc2f156956f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.toast','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal339c7fedf680433726dbafc2f156956f)): ?>
<?php $attributes = $__attributesOriginal339c7fedf680433726dbafc2f156956f; ?>
<?php unset($__attributesOriginal339c7fedf680433726dbafc2f156956f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal339c7fedf680433726dbafc2f156956f)): ?>
<?php $component = $__componentOriginal339c7fedf680433726dbafc2f156956f; ?>
<?php unset($__componentOriginal339c7fedf680433726dbafc2f156956f); ?>
<?php endif; ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>