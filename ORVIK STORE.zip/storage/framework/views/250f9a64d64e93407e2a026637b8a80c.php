<?php
    $currency = $business->currency === 'USD' ? '$' : 'Rs. ';
?>

<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Stock Movement Audit Trail','subtitle' => 'Chronological history of all stock changes','activeNav' => 'reports']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Stock Movement Audit Trail','subtitle' => 'Chronological history of all stock changes','activeNav' => 'reports']); ?>
    <div class="space-y-6">
        <!-- Header -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('app.reports')); ?>" class="p-2 rounded-xl bg-white border border-border text-muted-foreground hover:text-foreground">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                </a>
                <div>
                    <h1 class="text-xl font-bold tracking-tight text-foreground">Stock Movement Audit Trail</h1>
                    <p class="text-xs text-muted-foreground">Period: <strong class="text-foreground font-semibold"><?php echo e($dateRange['label']); ?></strong></p>
                </div>
            </div>

            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('app.reports.inventory')); ?>" class="px-3 py-2 rounded-xl bg-white border border-border text-foreground font-semibold text-xs flex items-center gap-1.5 hover:bg-secondary">
                    <i data-lucide="boxes" class="w-3.5 h-3.5 text-muted-foreground"></i>
                    <span>Inventory Status</span>
                </a>
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-1">
                <span class="text-[11px] font-semibold text-muted-foreground">Total Stock Movements</span>
                <p class="text-base font-extrabold font-mono text-foreground"><?php echo e(number_format($summary['total_movements'])); ?></p>
            </div>
            <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-1">
                <span class="text-[11px] font-semibold text-emerald-700">Total Stock Ingested</span>
                <p class="text-base font-extrabold font-mono text-emerald-700">+<?php echo e(number_format($summary['total_stock_in'])); ?> units</p>
            </div>
            <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-1">
                <span class="text-[11px] font-semibold text-rose-700">Total Stock Outflow</span>
                <p class="text-base font-extrabold font-mono text-rose-700">-<?php echo e(number_format($summary['total_stock_out'])); ?> units</p>
            </div>
        </div>

        <!-- Filter Bar -->
        <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-3">
            <form method="GET" action="<?php echo e(route('app.reports.inventory.movements')); ?>" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                <div class="lg:col-span-2 relative">
                    <i data-lucide="search" class="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2"></i>
                    <input
                        type="text"
                        name="search"
                        value="<?php echo e(request('search')); ?>"
                        placeholder="Search product, reference, notes..."
                        class="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-border bg-background text-foreground"
                    />
                </div>

                <div>
                    <select
                        name="movement_type"
                        onchange="this.form.submit()"
                        class="w-full px-3 py-2 text-xs rounded-xl border border-border bg-background text-foreground"
                    >
                        <option value="all">All Movement Types</option>
                        <option value="SALE" <?php echo e(request('movement_type') === 'SALE' ? 'selected' : ''); ?>>SALE</option>
                        <option value="PURCHASE" <?php echo e(request('movement_type') === 'PURCHASE' ? 'selected' : ''); ?>>PURCHASE</option>
                        <option value="SALE_RETURN" <?php echo e(request('movement_type') === 'SALE_RETURN' ? 'selected' : ''); ?>>SALE RETURN / VOID</option>
                        <option value="PURCHASE_VOID" <?php echo e(request('movement_type') === 'PURCHASE_VOID' ? 'selected' : ''); ?>>PURCHASE VOID</option>
                        <option value="ADJUSTMENT_ADD" <?php echo e(request('movement_type') === 'ADJUSTMENT_ADD' ? 'selected' : ''); ?>>ADJUSTMENT (+)</option>
                        <option value="ADJUSTMENT_REMOVE" <?php echo e(request('movement_type') === 'ADJUSTMENT_REMOVE' ? 'selected' : ''); ?>>ADJUSTMENT (-)</option>
                    </select>
                </div>

                <div>
                    <select
                        name="product_id"
                        onchange="this.form.submit()"
                        class="w-full px-3 py-2 text-xs rounded-xl border border-border bg-background text-foreground"
                    >
                        <option value="all">All Products</option>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($p->id); ?>" <?php echo e(request('product_id') == $p->id ? 'selected' : ''); ?>><?php echo e($p->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="flex items-center gap-2">
                    <button type="submit" class="w-full py-2 px-3 bg-secondary text-foreground hover:bg-muted font-bold text-xs rounded-xl">
                        Filter
                    </button>
                    <a href="<?php echo e(route('app.reports.inventory.movements')); ?>" class="py-2 px-3 text-xs text-muted-foreground hover:text-foreground font-semibold">
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Table -->
        <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginal793d2b22631f88b8a3d00569a12acf88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal793d2b22631f88b8a3d00569a12acf88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table','data' => ['headers' => ['Date & Time', 'Product Name', 'Movement Type', 'Quantity', 'Prev Stock', 'New Stock', 'Reference / Operator']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Date & Time', 'Product Name', 'Movement Type', 'Quantity', 'Prev Stock', 'New Stock', 'Reference / Operator'])]); ?>
                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-muted/20 transition-colors text-xs">
                        <td class="px-5 py-3.5 text-muted-foreground font-mono whitespace-nowrap">
                            <?php echo e($m->created_at ? $m->created_at->format('M d, Y H:i') : ''); ?>

                        </td>
                        <td class="px-5 py-3.5 font-bold text-foreground">
                            <?php echo e($m->product ? $m->product->name : 'Deleted Product'); ?>

                        </td>
                        <td class="px-5 py-3.5">
                            <span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono <?php echo e(str_contains($m->type, 'PURCHASE') || str_contains($m->type, 'ADD') ? 'bg-emerald-100 text-emerald-800' : 'bg-secondary text-foreground'); ?>">
                                <?php echo e($m->type); ?>

                            </span>
                        </td>
                        <td class="px-5 py-3.5 font-mono font-extrabold <?php echo e($m->quantity > 0 ? 'text-emerald-700' : 'text-rose-700'); ?>">
                            <?php echo e($m->quantity > 0 ? '+' : ''); ?><?php echo e((float)$m->quantity); ?>

                        </td>
                        <td class="px-5 py-3.5 font-mono text-muted-foreground">
                            <?php echo e((float)$m->previous_quantity); ?>

                        </td>
                        <td class="px-5 py-3.5 font-mono font-bold text-foreground">
                            <?php echo e((float)$m->new_quantity); ?>

                        </td>
                        <td class="px-5 py-3.5 text-muted-foreground text-[11px]">
                            <span><?php echo e($m->reference ?: '—'); ?></span>
                            <?php if($m->user): ?>
                                <span class="block text-[10px] text-muted-foreground/80 font-mono">By: <?php echo e($m->user->name); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="px-5 py-12 text-center text-xs text-muted-foreground">
                            No stock movement records found for this period.
                        </td>
                    </tr>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $attributes = $__attributesOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $component = $__componentOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__componentOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>

            <?php if($rows->hasPages()): ?>
                <div class="px-5 py-4 border-t border-border">
                    <?php echo e($rows->links()); ?>

                </div>
            <?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/app/reports/inventory-movements.blade.php ENDPATH**/ ?>