<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'default', // active, low-stock, out-of-stock, completed, pending, cancelled, archived, accent, secondary
    'size' => 'md',
    'dot' => true,
    'icon' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'default', // active, low-stock, out-of-stock, completed, pending, cancelled, archived, accent, secondary
    'size' => 'md',
    'dot' => true,
    'icon' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $variant = strtolower($variant);

    $styles = match($variant) {
        'active', 'completed', 'success' => [
            'class' => 'bg-emerald-50 text-emerald-700 border-emerald-200/60',
            'dot' => 'bg-emerald-500',
            'icon' => 'check-circle-2',
        ],
        'low-stock', 'low stock', 'warning' => [
            'class' => 'bg-amber-50 text-amber-700 border-amber-200/60',
            'dot' => 'bg-amber-500',
            'icon' => 'alert-triangle',
        ],
        'out-of-stock', 'out of stock', 'danger', 'destructive' => [
            'class' => 'bg-rose-50 text-rose-700 border-rose-200/60',
            'dot' => 'bg-rose-500',
            'icon' => 'alert-circle',
        ],
        'pending' => [
            'class' => 'bg-sky-50 text-sky-700 border-sky-200/60',
            'dot' => 'bg-sky-500',
            'icon' => 'clock',
        ],
        'cancelled', 'archived' => [
            'class' => 'bg-zinc-100 text-zinc-600 border-zinc-200',
            'dot' => 'bg-zinc-400',
            'icon' => 'archive',
        ],
        'accent' => [
            'class' => 'bg-accent/10 text-accent border-accent/20',
            'dot' => 'bg-accent',
            'icon' => 'sparkles',
        ],
        default => [
            'class' => 'bg-secondary text-secondary-foreground border-border',
            'dot' => 'bg-foreground/40',
            'icon' => null,
        ],
    };

    $sizeClasses = match($size) {
        'sm' => 'text-[11px] px-2 py-0.5 gap-1',
        'lg' => 'text-xs px-3 py-1.5 gap-2',
        default => 'text-xs px-2.5 py-1 gap-1.5',
    };
?>

<span <?php echo e($attributes->merge(['class' => "inline-flex items-center font-medium rounded-full border {$styles['class']} {$sizeClasses} select-none"])); ?>>
    <?php if($dot): ?>
        <span class="w-1.5 h-1.5 rounded-full <?php echo e($styles['dot']); ?> shrink-0"></span>
    <?php elseif($icon || $styles['icon']): ?>
        <i data-lucide="<?php echo e($icon ?? $styles['icon']); ?>" class="w-3 h-3 shrink-0"></i>
    <?php endif; ?>
    <span><?php echo e($slot); ?></span>
</span>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/ui/badge.blade.php ENDPATH**/ ?>