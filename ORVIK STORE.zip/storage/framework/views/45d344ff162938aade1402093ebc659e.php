<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'active' => 'dashboard',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'active' => 'dashboard',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $user = auth()->user();
    $business = $user?->currentBusiness();

    $allNavItems = [
        ['id' => 'dashboard', 'label' => 'Dashboard', 'route' => 'app.dashboard', 'icon' => 'layout-dashboard', 'badge' => null, 'permission' => 'dashboard.view'],
        ['id' => 'sales', 'label' => 'Sales', 'route' => 'app.sales', 'icon' => 'shopping-cart', 'badge' => 'POS', 'badgeVariant' => 'accent', 'permission' => 'sales.view'],
        ['id' => 'inventory', 'label' => 'Inventory', 'route' => 'app.inventory.index', 'icon' => 'boxes', 'badge' => null, 'permission' => 'inventory.view'],
        ['id' => 'customers', 'label' => 'Customers', 'route' => 'app.customers.index', 'icon' => 'users', 'badge' => null, 'permission' => 'customers.view'],
        ['id' => 'suppliers', 'label' => 'Suppliers', 'route' => 'app.suppliers.index', 'icon' => 'truck', 'badge' => null, 'permission' => 'suppliers.view'],
        ['id' => 'purchases', 'label' => 'Purchases', 'route' => 'app.purchases.index', 'icon' => 'package-plus', 'badge' => null, 'permission' => 'purchases.view'],
        ['id' => 'expenses', 'label' => 'Expenses', 'route' => 'app.expenses.index', 'icon' => 'receipt', 'badge' => null, 'permission' => 'expenses.view'],
        ['id' => 'reports', 'label' => 'Reports', 'route' => 'app.reports', 'icon' => 'bar-chart-3', 'badge' => null, 'permission' => 'reports.view'],
        ['id' => 'settings', 'label' => 'Settings', 'route' => 'app.settings', 'icon' => 'settings', 'badge' => null, 'permission' => null],
    ];

    $navItems = array_filter($allNavItems, function ($item) use ($user) {
        if (!$item['permission']) return true;
        return $user && $user->hasPermissionTo($item['permission']);
    });
?>

<aside class="hidden lg:flex flex-col w-64 bg-white border-r border-border min-h-screen shrink-0 select-none">
    <!-- Brand Header -->
    <div class="h-16 px-6 flex items-center border-b border-border/70">
        <?php if (isset($component)) { $__componentOriginal8641339168305ca7d1df3ab05341c05a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8641339168305ca7d1df3ab05341c05a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.branding.logo','data' => ['size' => 'md','href' => ''.e(route('app.dashboard')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('branding.logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['size' => 'md','href' => ''.e(route('app.dashboard')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8641339168305ca7d1df3ab05341c05a)): ?>
<?php $attributes = $__attributesOriginal8641339168305ca7d1df3ab05341c05a; ?>
<?php unset($__attributesOriginal8641339168305ca7d1df3ab05341c05a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8641339168305ca7d1df3ab05341c05a)): ?>
<?php $component = $__componentOriginal8641339168305ca7d1df3ab05341c05a; ?>
<?php unset($__componentOriginal8641339168305ca7d1df3ab05341c05a); ?>
<?php endif; ?>
    </div>

    <!-- Navigation Menu -->
    <div class="flex-1 py-6 px-4 space-y-1.5 overflow-y-auto">
        <div class="px-3 pb-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            Stall Operations
        </div>

        <?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $isActive = ($item['id'] === $active);
            ?>
            <a
                href="<?php echo e(route($item['route'])); ?>"
                class="flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm font-medium transition-all group <?php echo e($isActive ? 'bg-secondary text-foreground font-semibold shadow-xs' : 'text-muted-foreground hover:bg-muted/70 hover:text-foreground'); ?>"
            >
                <div class="flex items-center gap-3">
                    <i data-lucide="<?php echo e($item['icon']); ?>" class="w-4 h-4 transition-transform group-hover:scale-110 <?php echo e($isActive ? 'text-accent' : 'text-muted-foreground group-hover:text-foreground'); ?>"></i>
                    <span><?php echo e($item['label']); ?></span>
                </div>

                <?php if($item['badge']): ?>
                    <?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['variant' => $item['badgeVariant'] ?? 'secondary','size' => 'sm','dot' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item['badgeVariant'] ?? 'secondary'),'size' => 'sm','dot' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
                        <?php echo e($item['badge']); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
                <?php endif; ?>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Store Status Footer -->
    <div class="p-4 border-t border-border/70 bg-muted/20">
        <div class="flex items-center justify-between p-3 rounded-lg bg-white border border-border/60 shadow-2xs">
            <div class="flex items-center gap-2.5 min-w-0">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
                <div class="truncate">
                    <p class="text-xs font-semibold text-foreground truncate"><?php echo e($business?->name ?? 'Active Stall'); ?></p>
                    <p class="text-[11px] text-muted-foreground"><?php echo e($business?->currency ?? 'PKR'); ?> &bull; <?php echo e($user?->currentRole()?->display_name ?? 'Operator'); ?></p>
                </div>
            </div>
            <a href="<?php echo e(route('app.settings')); ?>" class="p-1 text-muted-foreground hover:text-foreground shrink-0">
                <i data-lucide="settings" class="w-4 h-4"></i>
            </a>
        </div>
    </div>
</aside>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/navigation/app-sidebar.blade.php ENDPATH**/ ?>