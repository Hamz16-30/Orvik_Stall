<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'size' => 'md',
    'href' => '/',
    'showText' => true,
    'customClass' => '',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'size' => 'md',
    'href' => '/',
    'showText' => true,
    'customClass' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $sizeClasses = match($size) {
        'sm' => 'text-lg gap-1.5',
        'lg' => 'text-2xl gap-2.5',
        'xl' => 'text-3xl gap-3',
        default => 'text-xl gap-2',
    };
    $markClasses = match($size) {
        'sm' => 'text-accent text-base',
        'lg' => 'text-accent text-2xl',
        'xl' => 'text-accent text-3xl',
        default => 'text-accent text-lg',
    };
?>

<a href="<?php echo e($href); ?>" class="inline-flex items-center font-bold tracking-tight text-foreground select-none transition-opacity hover:opacity-90 <?php echo e($sizeClasses); ?> <?php echo e($customClass); ?>">
    <span class="inline-block transition-transform duration-300 group-hover:rotate-12 <?php echo e($markClasses); ?>">&#10022;</span>
    <?php if($showText): ?>
        <span class="font-bold tracking-tight text-foreground">ORVIK <span class="font-medium text-foreground/80">Store</span></span>
    <?php endif; ?>
</a>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/branding/logo.blade.php ENDPATH**/ ?>