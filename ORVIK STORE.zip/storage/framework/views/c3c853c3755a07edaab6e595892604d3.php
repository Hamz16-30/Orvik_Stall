<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Plan Comparison Matrix — ORVIK Store</title>
    <meta name="description" content="Detailed side-by-side feature and quota comparison of all ORVIK Store SaaS tiers.">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-background text-foreground font-body antialiased selection:bg-accent/20 selection:text-accent">
    <!-- Marketing Navbar -->
    <?php if (isset($component)) { $__componentOriginal474ea26483bb67aedf11dde3d4971244 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal474ea26483bb67aedf11dde3d4971244 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navigation.marketing-navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation.marketing-navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal474ea26483bb67aedf11dde3d4971244)): ?>
<?php $attributes = $__attributesOriginal474ea26483bb67aedf11dde3d4971244; ?>
<?php unset($__attributesOriginal474ea26483bb67aedf11dde3d4971244); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal474ea26483bb67aedf11dde3d4971244)): ?>
<?php $component = $__componentOriginal474ea26483bb67aedf11dde3d4971244; ?>
<?php unset($__componentOriginal474ea26483bb67aedf11dde3d4971244); ?>
<?php endif; ?>

    <main class="py-16 md:py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
        <div class="text-center max-w-2xl mx-auto space-y-3">
            <a href="<?php echo e(route('pricing')); ?>" class="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1 mb-1">
                <i data-lucide="arrow-left" class="w-3.5 h-3.5"></i>
                <span>Back to Pricing</span>
            </a>
            <h1 class="text-3xl md:text-5xl font-normal font-serif tracking-tight text-foreground">
                Compare All Features & Limits
            </h1>
            <p class="text-sm text-muted-foreground">Find the exact tier tailored to your retail workflow.</p>
        </div>

        <div class="bg-white rounded-3xl border border-border/80 shadow-2xs overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-xs">
                    <thead>
                        <tr class="bg-secondary/70 border-b border-border text-foreground">
                            <th class="px-6 py-4 font-bold text-sm">Capability / Feature</th>
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="px-6 py-4 text-center">
                                    <p class="font-bold text-sm text-foreground"><?php echo e($plan->name); ?></p>
                                    <p class="font-mono text-[11px] text-muted-foreground">Rs. <?php echo e(number_format($plan->price)); ?>/mo</p>
                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-border/60">
                        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-muted/20 transition-colors">
                                <td class="px-6 py-3.5">
                                    <p class="font-semibold text-foreground"><?php echo e($feature->name); ?></p>
                                    <p class="text-[11px] text-muted-foreground"><?php echo e($feature->description); ?></p>
                                </td>
                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $pivot = $plan->features->firstWhere('id', $feature->id)?->pivot;
                                        $isEnabled = $pivot ? (bool)$pivot->enabled : false;
                                        $limitVal = $pivot ? $pivot->limit_value : null;
                                    ?>
                                    <td class="px-6 py-3.5 text-center font-mono">
                                        <?php if($feature->type === 'BOOLEAN'): ?>
                                            <?php if($isEnabled): ?>
                                                <i data-lucide="check" class="w-4 h-4 text-emerald-600 mx-auto"></i>
                                            <?php else: ?>
                                                <span class="text-muted-foreground">—</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if($limitVal === null): ?>
                                                <span class="font-bold text-accent">Unlimited (∞)</span>
                                            <?php else: ?>
                                                <span class="font-bold text-foreground"><?php echo e(number_format($limitVal)); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Public Footer -->
    <footer class="border-t border-border bg-white py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
        <p>&copy; <?php echo e(date('Y')); ?> ORVIK Store. All rights reserved.</p>
        <div class="flex items-center gap-6 font-medium">
            <a href="<?php echo e(route('pricing')); ?>" class="hover:text-foreground">Pricing</a>
            <a href="<?php echo e(route('privacy')); ?>" class="hover:text-foreground">Privacy Policy</a>
            <a href="<?php echo e(route('terms')); ?>" class="hover:text-foreground">Terms of Service</a>
            <a href="<?php echo e(route('cookie.policy')); ?>" class="hover:text-foreground">Cookie Policy</a>
        </div>
    </footer>
</body>
</html>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/landing/compare.blade.php ENDPATH**/ ?>