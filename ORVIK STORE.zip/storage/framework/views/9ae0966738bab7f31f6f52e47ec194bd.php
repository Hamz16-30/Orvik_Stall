<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'headers' => [],
    'striped' => false,
    'emptyMessage' => 'No records found.',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'headers' => [],
    'striped' => false,
    'emptyMessage' => 'No records found.',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="w-full overflow-hidden rounded-xl border border-border/80 bg-white shadow-sm">
    <div class="overflow-x-auto">
        <table <?php echo e($attributes->merge(['class' => 'w-full text-left border-collapse text-sm'])); ?>>
            <?php if(count($headers) > 0 || isset($thead)): ?>
                <thead class="bg-secondary/70 border-b border-border text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                    <?php if(isset($thead)): ?>
                        <?php echo e($thead); ?>

                    <?php else: ?>
                        <tr>
                            <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th scope="col" class="px-5 py-3.5 whitespace-nowrap"><?php echo e($header); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endif; ?>
                </thead>
            <?php endif; ?>

            <tbody class="divide-y divide-border/60 text-foreground">
                <?php echo e($slot); ?>

            </tbody>
        </table>
    </div>
</div>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/ui/table.blade.php ENDPATH**/ ?>