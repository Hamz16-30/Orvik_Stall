<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'items' => [
        ['name' => 'Artisan Leather Wallet', 'sku' => 'ALW-01', 'sold' => 48, 'revenue' => '$1,680.00', 'tag' => 'Top 1'],
        ['name' => 'Ceramic Brew Mug', 'sku' => 'CBM-09', 'sold' => 36, 'revenue' => '$864.00', 'tag' => 'Top 2'],
        ['name' => 'Linen Canvas Tote', 'sku' => 'LCT-14', 'sold' => 29, 'revenue' => '$725.00', 'tag' => 'Top 3'],
    ]
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'items' => [
        ['name' => 'Artisan Leather Wallet', 'sku' => 'ALW-01', 'sold' => 48, 'revenue' => '$1,680.00', 'tag' => 'Top 1'],
        ['name' => 'Ceramic Brew Mug', 'sku' => 'CBM-09', 'sold' => 36, 'revenue' => '$864.00', 'tag' => 'Top 2'],
        ['name' => 'Linen Canvas Tote', 'sku' => 'LCT-14', 'sold' => 29, 'revenue' => '$725.00', 'tag' => 'Top 3'],
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white p-5 rounded-xl border border-border/80 shadow-2xs">
    <div class="flex items-center justify-between pb-3 border-b border-border/50">
        <div>
            <h4 class="text-sm font-semibold text-foreground">Hot Selling Items</h4>
            <p class="text-[11px] text-muted-foreground">Fastest velocity this week</p>
        </div>
        <?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['variant' => 'accent','size' => 'sm','dot' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'accent','size' => 'sm','dot' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>High Demand <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
    </div>

    <div class="mt-3 divide-y divide-border/50">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="py-2.5 flex items-center justify-between gap-3 text-xs">
                <div class="flex items-center gap-2.5 min-w-0">
                    <span class="w-5 h-5 rounded-md bg-secondary flex items-center justify-center font-bold text-[10px] text-foreground shrink-0">
                        <?php echo e($loop->iteration); ?>

                    </span>
                    <div class="truncate">
                        <p class="font-semibold text-foreground truncate"><?php echo e($item['name']); ?></p>
                        <p class="text-[10px] text-muted-foreground"><?php echo e($item['sku']); ?> &bull; <?php echo e($item['sold']); ?> sold</p>
                    </div>
                </div>
                <div class="text-right shrink-0">
                    <p class="font-bold text-foreground"><?php echo e($item['revenue']); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/dashboard/hot-selling-list.blade.php ENDPATH**/ ?>