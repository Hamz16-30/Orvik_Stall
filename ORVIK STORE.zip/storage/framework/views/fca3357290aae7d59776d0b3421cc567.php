<?php
    $currency = $business->currency === 'USD' ? '$' : 'Rs. ';
?>

<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Sales Report','subtitle' => 'Itemized sales transactions and revenue ledger','activeNav' => 'reports']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Sales Report','subtitle' => 'Itemized sales transactions and revenue ledger','activeNav' => 'reports']); ?>
    <div x-data="{ filterModal: false, customRangeModal: false }" class="space-y-6">
        <!-- Top Navigation & Action Buttons -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('app.reports')); ?>" class="p-2 rounded-xl bg-white border border-border text-muted-foreground hover:text-foreground">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                </a>
                <div>
                    <h1 class="text-xl font-bold tracking-tight text-foreground">Sales Transactions Report</h1>
                    <p class="text-xs text-muted-foreground">Period: <strong class="text-foreground font-semibold"><?php echo e($dateRange['label']); ?></strong></p>
                </div>
            </div>

            <!-- Export Buttons -->
            <div class="flex items-center gap-2">
                <a
                    href="<?php echo e(route('app.reports.print', array_merge(['type' => 'sales'], request()->query()))); ?>"
                    target="_blank"
                    class="px-3 py-2 rounded-xl bg-white border border-border text-foreground font-semibold text-xs flex items-center gap-1.5 hover:bg-secondary shadow-2xs"
                >
                    <i data-lucide="printer" class="w-3.5 h-3.5 text-muted-foreground"></i>
                    <span>Print</span>
                </a>
                <a
                    href="<?php echo e(route('app.reports.export.csv', array_merge(['type' => 'sales'], request()->query()))); ?>"
                    class="px-3 py-2 rounded-xl bg-white border border-border text-foreground font-semibold text-xs flex items-center gap-1.5 hover:bg-secondary shadow-2xs"
                >
                    <i data-lucide="download" class="w-3.5 h-3.5 text-muted-foreground"></i>
                    <span>CSV</span>
                </a>
                <a
                    href="<?php echo e(route('app.reports.export.excel', array_merge(['type' => 'sales'], request()->query()))); ?>"
                    class="px-3 py-2 rounded-xl bg-white border border-border text-foreground font-semibold text-xs flex items-center gap-1.5 hover:bg-secondary shadow-2xs"
                >
                    <i data-lucide="file-spreadsheet" class="w-3.5 h-3.5 text-emerald-600"></i>
                    <span>Excel</span>
                </a>
            </div>
        </div>

        <!-- Summary Cards Row -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-1">
                <span class="text-[11px] font-semibold text-muted-foreground">Gross Sales</span>
                <p class="text-base font-extrabold font-mono text-foreground"><?php echo e($currency); ?><?php echo e(number_format($summary['gross_sales'], 2)); ?></p>
            </div>
            <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-1">
                <span class="text-[11px] font-semibold text-muted-foreground">Discounts</span>
                <p class="text-base font-extrabold font-mono text-emerald-700">-<?php echo e($currency); ?><?php echo e(number_format($summary['discounts'], 2)); ?></p>
            </div>
            <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-1">
                <span class="text-[11px] font-semibold text-muted-foreground">Taxes</span>
                <p class="text-base font-extrabold font-mono text-foreground"><?php echo e($currency); ?><?php echo e(number_format($summary['taxes'], 2)); ?></p>
            </div>
            <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-1 bg-accent/5">
                <span class="text-[11px] font-semibold text-accent">Net Sales</span>
                <p class="text-base font-extrabold font-mono text-accent"><?php echo e($currency); ?><?php echo e(number_format($summary['net_sales'], 2)); ?></p>
            </div>
            <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-1">
                <span class="text-[11px] font-semibold text-muted-foreground">Total Orders</span>
                <p class="text-base font-extrabold font-mono text-foreground"><?php echo e(number_format($summary['orders_count'])); ?></p>
            </div>
            <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-1">
                <span class="text-[11px] font-semibold text-muted-foreground">Avg Order Value</span>
                <p class="text-base font-extrabold font-mono text-foreground"><?php echo e($currency); ?><?php echo e(number_format($summary['average_order_value'], 2)); ?></p>
            </div>
        </div>

        <!-- Filter Bar -->
        <div class="bg-white p-4 rounded-2xl border border-border/80 shadow-2xs space-y-3">
            <form method="GET" action="<?php echo e(route('app.reports.sales')); ?>" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
                <!-- Search Input -->
                <div class="lg:col-span-2 relative">
                    <i data-lucide="search" class="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2"></i>
                    <input
                        type="text"
                        name="search"
                        value="<?php echo e(request('search')); ?>"
                        placeholder="Search by invoice # or customer..."
                        class="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-border bg-background text-foreground"
                    />
                </div>

                <!-- Date Range Selector -->
                <div>
                    <select
                        name="period"
                        onchange="if(this.value==='custom'){ customRangeModal = true; } else { this.form.submit(); }"
                        class="w-full px-3 py-2 text-xs rounded-xl border border-border bg-background text-foreground"
                    >
                        <option value="today" <?php echo e($period === 'today' ? 'selected' : ''); ?>>Today</option>
                        <option value="yesterday" <?php echo e($period === 'yesterday' ? 'selected' : ''); ?>>Yesterday</option>
                        <option value="this_week" <?php echo e($period === 'this_week' ? 'selected' : ''); ?>>This Week</option>
                        <option value="this_month" <?php echo e($period === 'this_month' ? 'selected' : ''); ?>>This Month</option>
                        <option value="last_month" <?php echo e($period === 'last_month' ? 'selected' : ''); ?>>Last Month</option>
                        <option value="custom" <?php echo e($period === 'custom' ? 'selected' : ''); ?>>Custom Range</option>
                    </select>
                </div>

                <!-- Payment Method -->
                <div>
                    <select
                        name="payment_method"
                        onchange="this.form.submit()"
                        class="w-full px-3 py-2 text-xs rounded-xl border border-border bg-background text-foreground"
                    >
                        <option value="all">All Payment Methods</option>
                        <option value="cash" <?php echo e(request('payment_method') === 'cash' ? 'selected' : ''); ?>>Cash</option>
                        <option value="card" <?php echo e(request('payment_method') === 'card' ? 'selected' : ''); ?>>Card</option>
                        <option value="mobile_payment" <?php echo e(request('payment_method') === 'mobile_payment' ? 'selected' : ''); ?>>Mobile Payment</option>
                        <option value="bank_transfer" <?php echo e(request('payment_method') === 'bank_transfer' ? 'selected' : ''); ?>>Bank Transfer</option>
                    </select>
                </div>

                <!-- Cashier / User -->
                <div>
                    <select
                        name="user_id"
                        onchange="this.form.submit()"
                        class="w-full px-3 py-2 text-xs rounded-xl border border-border bg-background text-foreground"
                    >
                        <option value="all">All Staff</option>
                        <?php $__currentLoopData = $cashiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>" <?php echo e(request('user_id') == $c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Submit / Reset -->
                <div class="flex items-center gap-2">
                    <button type="submit" class="w-full py-2 px-3 bg-secondary text-foreground hover:bg-muted font-bold text-xs rounded-xl">
                        Filter
                    </button>
                    <a href="<?php echo e(route('app.reports.sales')); ?>" class="py-2 px-3 text-xs text-muted-foreground hover:text-foreground font-semibold">
                        Reset
                    </a>
                </div>
            </form>
        </div>

        <!-- Sales Data Table -->
        <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginal793d2b22631f88b8a3d00569a12acf88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal793d2b22631f88b8a3d00569a12acf88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table','data' => ['headers' => ['Invoice #', 'Date & Time', 'Customer', 'Items', 'Subtotal', 'Discount', 'Total', 'Payment', 'Status', 'Actions']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Invoice #', 'Date & Time', 'Customer', 'Items', 'Subtotal', 'Discount', 'Total', 'Payment', 'Status', 'Actions'])]); ?>
                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-muted/20 transition-colors text-xs">
                        <td class="px-5 py-3.5 font-mono font-bold text-foreground">
                            <a href="<?php echo e(route('app.sales.show', $sale->id)); ?>" class="hover:text-accent hover:underline">
                                <?php echo e($sale->invoice_number); ?>

                            </a>
                        </td>
                        <td class="px-5 py-3.5 text-muted-foreground font-mono whitespace-nowrap">
                            <?php echo e($sale->completed_at ? $sale->completed_at->format('M d, Y H:i') : ''); ?>

                        </td>
                        <td class="px-5 py-3.5 font-semibold text-foreground">
                            <?php if($sale->customer): ?>
                                <a href="<?php echo e(route('app.customers.show', $sale->customer->id)); ?>" class="hover:underline hover:text-accent">
                                    <?php echo e($sale->customer->name); ?>

                                </a>
                            <?php else: ?>
                                <span class="text-muted-foreground font-normal">Walk-in</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-5 py-3.5 text-muted-foreground">
                            <?php echo e($sale->items->count()); ?> item(s)
                        </td>
                        <td class="px-5 py-3.5 font-mono text-muted-foreground">
                            <?php echo e($currency); ?><?php echo e(number_format($sale->subtotal, 2)); ?>

                        </td>
                        <td class="px-5 py-3.5 font-mono text-emerald-700">
                            <?php echo e($sale->discount_amount > 0 ? '-' . $currency . number_format($sale->discount_amount, 2) : '—'); ?>

                        </td>
                        <td class="px-5 py-3.5 font-mono font-extrabold text-foreground">
                            <?php echo e($currency); ?><?php echo e(number_format($sale->total_amount, 2)); ?>

                        </td>
                        <td class="px-5 py-3.5 capitalize text-foreground">
                            <?php echo e(str_replace('_', ' ', $sale->payment_method)); ?>

                        </td>
                        <td class="px-5 py-3.5">
                            <?php if($sale->status === 'completed'): ?>
                                <?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['variant' => 'in-stock','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'in-stock','size' => 'sm']); ?>Completed <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if (isset($component)) { $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.badge','data' => ['variant' => 'destructive','size' => 'sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'destructive','size' => 'sm']); ?>Voided <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $attributes = $__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__attributesOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4)): ?>
<?php $component = $__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4; ?>
<?php unset($__componentOriginalab7baa01105b3dfe1e0cf1dfc58879b4); ?>
<?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="px-5 py-3.5 text-xs">
                            <div class="flex items-center gap-1.5">
                                <a href="<?php echo e(route('app.sales.show', $sale->id)); ?>" class="p-1 text-muted-foreground hover:text-accent" title="View Sale">
                                    <i data-lucide="eye" class="w-4 h-4"></i>
                                </a>
                                <a href="<?php echo e(route('app.sales.receipt', $sale->id)); ?>" target="_blank" class="p-1 text-muted-foreground hover:text-accent" title="Receipt">
                                    <i data-lucide="printer" class="w-4 h-4"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" class="px-5 py-12 text-center text-xs text-muted-foreground">
                            No sales records found for the selected filters.
                        </td>
                    </tr>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $attributes = $__attributesOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $component = $__componentOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__componentOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>

            <?php if($rows->hasPages()): ?>
                <div class="px-5 py-4 border-t border-border">
                    <?php echo e($rows->links()); ?>

                </div>
            <?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/app/reports/sales.blade.php ENDPATH**/ ?>