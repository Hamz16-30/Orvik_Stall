<?php
    $currency = $business->currency === 'USD' ? '$' : 'Rs. ';
?>

<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Profitability Report','subtitle' => 'Gross profit, margins, and estimated operating profit','activeNav' => 'reports']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Profitability Report','subtitle' => 'Gross profit, margins, and estimated operating profit','activeNav' => 'reports']); ?>
    <div class="space-y-6">
        <!-- Header -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div class="flex items-center gap-2">
                <a href="<?php echo e(route('app.reports')); ?>" class="p-2 rounded-xl bg-white border border-border text-muted-foreground hover:text-foreground">
                    <i data-lucide="arrow-left" class="w-4 h-4"></i>
                </a>
                <div>
                    <h1 class="text-xl font-bold tracking-tight text-foreground">Executive Profitability & Margins</h1>
                    <p class="text-xs text-muted-foreground">Period: <strong class="text-foreground font-semibold"><?php echo e($dateRange['label']); ?></strong></p>
                </div>
            </div>

            <!-- Export Buttons -->
            <div class="flex items-center gap-2">
                <a
                    href="<?php echo e(route('app.reports.print', array_merge(['type' => 'profit'], request()->query()))); ?>"
                    target="_blank"
                    class="px-3 py-2 rounded-xl bg-white border border-border text-foreground font-semibold text-xs flex items-center gap-1.5 hover:bg-secondary shadow-2xs"
                >
                    <i data-lucide="printer" class="w-3.5 h-3.5 text-muted-foreground"></i>
                    <span>Print</span>
                </a>
                <a
                    href="<?php echo e(route('app.reports.export.csv', array_merge(['type' => 'profit'], request()->query()))); ?>"
                    class="px-3 py-2 rounded-xl bg-white border border-border text-foreground font-semibold text-xs flex items-center gap-1.5 hover:bg-secondary shadow-2xs"
                >
                    <i data-lucide="download" class="w-3.5 h-3.5 text-muted-foreground"></i>
                    <span>CSV</span>
                </a>
                <a
                    href="<?php echo e(route('app.reports.export.excel', array_merge(['type' => 'profit'], request()->query()))); ?>"
                    class="px-3 py-2 rounded-xl bg-white border border-border text-foreground font-semibold text-xs flex items-center gap-1.5 hover:bg-secondary shadow-2xs"
                >
                    <i data-lucide="file-spreadsheet" class="w-3.5 h-3.5 text-emerald-600"></i>
                    <span>Excel</span>
                </a>
            </div>
        </div>

        <!-- Profit Calculation Formula Card -->
        <div class="bg-white p-5 rounded-2xl border border-border/80 shadow-2xs space-y-4">
            <div class="flex items-center justify-between">
                <span class="text-xs font-bold uppercase tracking-wider text-muted-foreground">Operating Profit Waterfall</span>
                <span class="text-[10px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                    Estimated Operating Profit (Non-GAAP)
                </span>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                <div class="p-3 bg-secondary/50 rounded-xl space-y-1">
                    <span class="text-[11px] font-semibold text-muted-foreground">1. Total Revenue</span>
                    <p class="text-base font-extrabold font-mono text-foreground"><?php echo e($currency); ?><?php echo e(number_format($kpis['revenue'], 2)); ?></p>
                </div>
                <div class="p-3 bg-secondary/50 rounded-xl space-y-1">
                    <span class="text-[11px] font-semibold text-muted-foreground">2. COGS (Cost of Goods)</span>
                    <p class="text-base font-extrabold font-mono text-muted-foreground">-<?php echo e($currency); ?><?php echo e(number_format($kpis['revenue'] - $kpis['gross_profit'], 2)); ?></p>
                </div>
                <div class="p-3 bg-emerald-50 rounded-xl space-y-1 border border-emerald-200/50">
                    <span class="text-[11px] font-semibold text-emerald-800">3. Gross Profit</span>
                    <p class="text-base font-extrabold font-mono text-emerald-700"><?php echo e($currency); ?><?php echo e(number_format($kpis['gross_profit'], 2)); ?></p>
                </div>
                <div class="p-3 bg-emerald-50 rounded-xl space-y-1 border border-emerald-200/50">
                    <span class="text-[11px] font-semibold text-emerald-800">Gross Margin %</span>
                    <p class="text-base font-extrabold font-mono text-emerald-700"><?php echo e($kpis['gross_margin']); ?>%</p>
                </div>
                <div class="p-3 bg-secondary/50 rounded-xl space-y-1">
                    <span class="text-[11px] font-semibold text-muted-foreground">4. Operating Expenses</span>
                    <p class="text-base font-extrabold font-mono text-rose-700">-<?php echo e($currency); ?><?php echo e(number_format($kpis['expenses'], 2)); ?></p>
                </div>
                <div class="p-3 bg-accent/10 rounded-xl space-y-1 border border-accent/20">
                    <span class="text-[11px] font-semibold text-accent">5. Net Operating Profit</span>
                    <p class="text-base font-extrabold font-mono <?php echo e($kpis['operating_profit'] >= 0 ? 'text-accent' : 'text-rose-700'); ?>">
                        <?php echo e($currency); ?><?php echo e(number_format($kpis['operating_profit'], 2)); ?>

                    </p>
                </div>
            </div>
        </div>

        <!-- Breakdown Timeline Table -->
        <?php if (isset($component)) { $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginal793d2b22631f88b8a3d00569a12acf88 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal793d2b22631f88b8a3d00569a12acf88 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.table','data' => ['headers' => ['Date', 'Revenue', 'Cost of Goods (COGS)', 'Gross Profit', 'Expenses', 'Est. Operating Profit']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['headers' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Date', 'Revenue', 'Cost of Goods (COGS)', 'Gross Profit', 'Expenses', 'Est. Operating Profit'])]); ?>
                <?php $__empty_1 = true; $__currentLoopData = $breakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($row['revenue'] > 0 || $row['expenses'] > 0): ?>
                        <tr class="hover:bg-muted/20 transition-colors text-xs">
                            <td class="px-5 py-4 font-bold text-foreground">
                                <?php echo e($row['date']); ?>

                            </td>
                            <td class="px-5 py-4 font-mono font-bold text-foreground">
                                <?php echo e($currency); ?><?php echo e(number_format($row['revenue'], 2)); ?>

                            </td>
                            <td class="px-5 py-4 font-mono text-muted-foreground">
                                <?php echo e($currency); ?><?php echo e(number_format($row['cogs'], 2)); ?>

                            </td>
                            <td class="px-5 py-4 font-mono font-bold text-emerald-700">
                                <?php echo e($currency); ?><?php echo e(number_format($row['gross_profit'], 2)); ?>

                            </td>
                            <td class="px-5 py-4 font-mono text-rose-700">
                                <?php echo e($row['expenses'] > 0 ? '-' . $currency . number_format($row['expenses'], 2) : '—'); ?>

                            </td>
                            <td class="px-5 py-4 font-mono font-extrabold <?php echo e($row['operating_profit'] >= 0 ? 'text-accent' : 'text-rose-700'); ?>">
                                <?php echo e($currency); ?><?php echo e(number_format($row['operating_profit'], 2)); ?>

                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-5 py-12 text-center text-xs text-muted-foreground">
                            No financial activity recorded in this date range.
                        </td>
                    </tr>
                <?php endif; ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $attributes = $__attributesOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__attributesOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal793d2b22631f88b8a3d00569a12acf88)): ?>
<?php $component = $__componentOriginal793d2b22631f88b8a3d00569a12acf88; ?>
<?php unset($__componentOriginal793d2b22631f88b8a3d00569a12acf88); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $attributes = $__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__attributesOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93)): ?>
<?php $component = $__componentOriginaldae4cd48acb67888a4631e1ba48f2f93; ?>
<?php unset($__componentOriginaldae4cd48acb67888a4631e1ba48f2f93); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/app/reports/profit.blade.php ENDPATH**/ ?>