<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => null,
    'id' => null,
    'name' => null,
    'type' => 'text',
    'placeholder' => '',
    'value' => '',
    'error' => null,
    'hint' => null,
    'disabled' => false,
    'required' => false,
    'icon' => null,
    'suffix' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => null,
    'id' => null,
    'name' => null,
    'type' => 'text',
    'placeholder' => '',
    'value' => '',
    'error' => null,
    'hint' => null,
    'disabled' => false,
    'required' => false,
    'icon' => null,
    'suffix' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $id = $id ?? $name ?? 'input-' . uniqid();
    $hasError = !empty($error) || ($name && $errors->has($name));
    $errorMessage = $error ?? ($name ? $errors->first($name) : null);
?>

<div class="w-full space-y-1.5">
    <?php if($label): ?>
        <label for="<?php echo e($id); ?>" class="block text-xs font-semibold uppercase tracking-wider text-foreground/80">
            <?php echo e($label); ?>

            <?php if($required): ?>
                <span class="text-rose-500">*</span>
            <?php endif; ?>
        </label>
    <?php endif; ?>

    <div class="relative rounded-lg shadow-sm">
        <?php if($icon): ?>
            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3.5 text-muted-foreground">
                <i data-lucide="<?php echo e($icon); ?>" class="h-4 w-4"></i>
            </div>
        <?php endif; ?>

        <input
            type="<?php echo e($type); ?>"
            id="<?php echo e($id); ?>"
            name="<?php echo e($name); ?>"
            value="<?php echo e(old($name, $value)); ?>"
            placeholder="<?php echo e($placeholder); ?>"
            <?php echo e($disabled ? 'disabled' : ''); ?>

            <?php echo e($required ? 'required' : ''); ?>

            <?php echo e($attributes->merge([
                'class' => 'block w-full min-h-[44px] rounded-lg border bg-white px-3.5 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/70 transition-colors focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20 disabled:cursor-not-allowed disabled:bg-muted/50 disabled:text-muted-foreground ' .
                ($icon ? 'pl-10 ' : '') .
                ($suffix ? 'pr-10 ' : '') .
                ($hasError ? 'border-rose-500 focus:border-rose-500 focus:ring-rose-500/20' : 'border-border')
            ])); ?>

        />

        <?php if($suffix): ?>
            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3.5 text-muted-foreground">
                <?php echo e($suffix); ?>

            </div>
        <?php endif; ?>
    </div>

    <?php if($errorMessage): ?>
        <p class="text-xs text-rose-600 flex items-center gap-1 font-medium mt-1">
            <i data-lucide="alert-circle" class="w-3.5 h-3.5 shrink-0"></i>
            <span><?php echo e($errorMessage); ?></span>
        </p>
    <?php elseif($hint): ?>
        <p class="text-xs text-muted-foreground mt-1"><?php echo e($hint); ?></p>
    <?php endif; ?>
</div>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/ui/input.blade.php ENDPATH**/ ?>