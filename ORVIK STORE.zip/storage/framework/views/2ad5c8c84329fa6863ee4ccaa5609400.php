<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'primary',
    'size' => 'md',
    'rounded' => 'full',
    'type' => 'button',
    'href' => null,
    'disabled' => false,
    'loading' => false,
    'icon' => null,
    'iconPosition' => 'left',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'primary',
    'size' => 'md',
    'rounded' => 'full',
    'type' => 'button',
    'href' => null,
    'disabled' => false,
    'loading' => false,
    'icon' => null,
    'iconPosition' => 'left',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $baseClasses = 'inline-flex items-center justify-center font-medium transition-all duration-200 select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none active:scale-[0.98]';

    $variantClasses = match($variant) {
        'accent' => 'bg-accent text-accent-foreground hover:bg-accent/90 shadow-sm shadow-accent/20 active:bg-accent/95',
        'secondary' => 'bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border/80 shadow-sm',
        'ghost' => 'bg-transparent text-foreground hover:bg-muted text-muted-foreground hover:text-foreground',
        'destructive' => 'bg-rose-600 text-white hover:bg-rose-700 shadow-sm active:bg-rose-800',
        'outline' => 'bg-transparent border border-border text-foreground hover:bg-muted',
        default => 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm',
    };

    $sizeClasses = match($size) {
        'sm' => 'text-xs px-3 py-1.5 min-h-[36px] gap-1.5',
        'lg' => 'text-base px-7 py-3 min-h-[52px] gap-2.5',
        'icon' => 'p-2.5 min-h-[44px] min-w-[44px] justify-center',
        default => 'text-sm px-5 py-2.5 min-h-[44px] gap-2',
    };

    $roundedClasses = match($rounded) {
        'lg' => 'rounded-lg',
        'md' => 'rounded-md',
        'none' => 'rounded-none',
        default => 'rounded-full',
    };

    $classes = "{$baseClasses} {$variantClasses} {$sizeClasses} {$roundedClasses}";
?>

<?php if($href): ?>
    <a href="<?php echo e($href); ?>" <?php echo e($attributes->merge(['class' => $classes])); ?>>
        <?php if($icon && $iconPosition === 'left'): ?>
            <i data-lucide="<?php echo e($icon); ?>" class="w-4 h-4 shrink-0"></i>
        <?php endif; ?>

        <?php echo e($slot); ?>


        <?php if($icon && $iconPosition === 'right'): ?>
            <i data-lucide="<?php echo e($icon); ?>" class="w-4 h-4 shrink-0"></i>
        <?php endif; ?>
    </a>
<?php else: ?>
    <button type="<?php echo e($type); ?>" <?php echo e($disabled || $loading ? 'disabled' : ''); ?> <?php echo e($attributes->merge(['class' => $classes])); ?>>
        <?php if($loading): ?>
            <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path>
            </svg>
        <?php elseif($icon && $iconPosition === 'left'): ?>
            <i data-lucide="<?php echo e($icon); ?>" class="w-4 h-4 shrink-0"></i>
        <?php endif; ?>

        <?php echo e($slot); ?>


        <?php if($icon && $iconPosition === 'right' && !$loading): ?>
            <i data-lucide="<?php echo e($icon); ?>" class="w-4 h-4 shrink-0"></i>
        <?php endif; ?>
    </button>
<?php endif; ?>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/ui/button.blade.php ENDPATH**/ ?>