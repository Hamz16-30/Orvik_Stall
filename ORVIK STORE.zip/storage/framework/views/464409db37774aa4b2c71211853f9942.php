<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => 'Total Sales',
    'value' => '$0.00',
    'change' => '+0.0%',
    'trend' => 'up', // up, down, neutral
    'icon' => 'dollar-sign',
    'badge' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => 'Total Sales',
    'value' => '$0.00',
    'change' => '+0.0%',
    'trend' => 'up', // up, down, neutral
    'icon' => 'dollar-sign',
    'badge' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white p-4 sm:p-5 rounded-xl border border-border/80 shadow-2xs hover:shadow-xs transition-shadow">
    <div class="flex items-center justify-between">
        <span class="text-xs font-semibold text-muted-foreground uppercase tracking-wider"><?php echo e($label); ?></span>
        <div class="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center text-foreground/80">
            <i data-lucide="<?php echo e($icon); ?>" class="w-4 h-4"></i>
        </div>
    </div>

    <div class="mt-3 flex items-baseline justify-between">
        <h4 class="text-xl sm:text-2xl font-bold tracking-tight text-foreground"><?php echo e($value); ?></h4>
        <?php if($change): ?>
            <div class="flex items-center gap-1 text-xs font-semibold <?php echo e($trend === 'up' ? 'text-emerald-600' : ($trend === 'down' ? 'text-rose-600' : 'text-muted-foreground')); ?>">
                <?php if($trend === 'up'): ?>
                    <i data-lucide="trending-up" class="w-3.5 h-3.5"></i>
                <?php elseif($trend === 'down'): ?>
                    <i data-lucide="trending-down" class="w-3.5 h-3.5"></i>
                <?php endif; ?>
                <span><?php echo e($change); ?></span>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/dashboard/metric-card.blade.php ENDPATH**/ ?>