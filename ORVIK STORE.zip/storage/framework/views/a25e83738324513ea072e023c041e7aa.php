<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => null,
    'description' => null,
    'headerActions' => null,
    'footer' => null,
    'padding' => 'p-6',
    'shadow' => 'shadow-sm',
    'border' => 'border border-border/80',
    'bg' => 'bg-white',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => null,
    'description' => null,
    'headerActions' => null,
    'footer' => null,
    'padding' => 'p-6',
    'shadow' => 'shadow-sm',
    'border' => 'border border-border/80',
    'bg' => 'bg-white',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div <?php echo e($attributes->merge(['class' => "{$bg} {$border} {$shadow} rounded-xl overflow-hidden"])); ?>>
    <?php if($title || $description || $headerActions || isset($header)): ?>
        <div class="px-6 py-4 border-b border-border/60 flex items-center justify-between gap-4">
            <?php if(isset($header)): ?>
                <?php echo e($header); ?>

            <?php else: ?>
                <div>
                    <?php if($title): ?>
                        <h3 class="text-base font-semibold text-foreground tracking-tight"><?php echo e($title); ?></h3>
                    <?php endif; ?>
                    <?php if($description): ?>
                        <p class="text-xs text-muted-foreground mt-0.5"><?php echo e($description); ?></p>
                    <?php endif; ?>
                </div>
                <?php if($headerActions): ?>
                    <div class="flex items-center gap-2">
                        <?php echo e($headerActions); ?>

                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="<?php echo e($padding); ?>">
        <?php echo e($slot); ?>

    </div>

    <?php if($footer): ?>
        <div class="px-6 py-3.5 bg-muted/40 border-t border-border/60 text-xs text-muted-foreground">
            <?php echo e($footer); ?>

        </div>
    <?php endif; ?>
</div>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/ui/card.blade.php ENDPATH**/ ?>