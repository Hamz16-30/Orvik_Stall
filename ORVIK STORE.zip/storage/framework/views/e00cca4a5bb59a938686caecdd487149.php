<div class="rounded-2xl overflow-hidden p-2 sm:p-4 glass-preview-container select-none">
    <!-- Inner Mock App Window -->
    <div class="rounded-xl overflow-hidden bg-white border border-border/80 shadow-sm flex flex-col">
        <!-- Mock Browser / App Titlebar -->
        <div class="h-10 px-4 bg-secondary/60 border-b border-border/70 flex items-center justify-between">
            <div class="flex items-center gap-2">
                <span class="w-3 h-3 rounded-full bg-rose-400/80"></span>
                <span class="w-3 h-3 rounded-full bg-amber-400/80"></span>
                <span class="w-3 h-3 rounded-full bg-emerald-400/80"></span>
                <span class="text-[11px] font-mono text-muted-foreground ml-2 hidden sm:inline">app.orvikstore.com/dashboard</span>
            </div>
            <div class="flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span class="text-[11px] font-medium text-muted-foreground">Live POS Sync</span>
            </div>
        </div>

        <div class="flex">
            <!-- Mock Mini Sidebar (Desktop only) -->
            <div class="hidden md:flex flex-col w-48 bg-secondary/30 border-r border-border/70 p-3 space-y-1">
                <div class="flex items-center gap-2 px-2 py-1.5 mb-2">
                    <span class="text-accent text-sm font-bold">&#10022;</span>
                    <span class="text-xs font-bold text-foreground">ORVIK Store</span>
                </div>

                <div class="px-2.5 py-1.5 rounded-lg bg-white border border-border/70 text-xs font-semibold text-foreground flex items-center gap-2">
                    <i data-lucide="layout-dashboard" class="w-3.5 h-3.5 text-accent"></i>
                    <span>Dashboard</span>
                </div>
                <div class="px-2.5 py-1.5 rounded-lg text-xs font-medium text-muted-foreground hover:text-foreground flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <i data-lucide="shopping-cart" class="w-3.5 h-3.5"></i>
                        <span>Sales</span>
                    </div>
                    <span class="text-[9px] bg-accent/10 text-accent font-bold px-1.5 py-0.2 rounded">POS</span>
                </div>
                <div class="px-2.5 py-1.5 rounded-lg text-xs font-medium text-muted-foreground hover:text-foreground flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <i data-lucide="boxes" class="w-3.5 h-3.5"></i>
                        <span>Inventory</span>
                    </div>
                    <span class="text-[9px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded">3 Low</span>
                </div>
                <div class="px-2.5 py-1.5 rounded-lg text-xs font-medium text-muted-foreground hover:text-foreground flex items-center gap-2">
                    <i data-lucide="bar-chart-3" class="w-3.5 h-3.5"></i>
                    <span>Reports</span>
                </div>
                <div class="px-2.5 py-1.5 rounded-lg text-xs font-medium text-muted-foreground hover:text-foreground flex items-center gap-2">
                    <i data-lucide="users" class="w-3.5 h-3.5"></i>
                    <span>Customers</span>
                </div>
            </div>

            <!-- Mock Dashboard Body -->
            <div class="flex-1 p-3 sm:p-5 bg-secondary/15 space-y-4">
                <!-- Top Mini Header -->
                <div class="flex items-center justify-between gap-2">
                    <div>
                        <h3 class="text-base sm:text-lg font-bold text-foreground tracking-tight">Main Stall Performance</h3>
                        <p class="text-[11px] text-muted-foreground">Today: Sunday, August 16, 2026</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['variant' => 'accent','size' => 'sm','rounded' => 'lg','icon' => 'plus','class' => 'text-xs h-8 px-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'accent','size' => 'sm','rounded' => 'lg','icon' => 'plus','class' => 'text-xs h-8 px-3']); ?>
                            New Sale
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
                    </div>
                </div>

                <!-- 4 Metrics Grid -->
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    <?php if (isset($component)) { $__componentOriginalc57c361e10a050969f1a9ef52bca9009 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc57c361e10a050969f1a9ef52bca9009 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric-card','data' => ['label' => 'Today\'s Sales','value' => '$2,845.50','change' => '+18.2%','trend' => 'up','icon' => 'dollar-sign']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Today\'s Sales','value' => '$2,845.50','change' => '+18.2%','trend' => 'up','icon' => 'dollar-sign']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc57c361e10a050969f1a9ef52bca9009)): ?>
<?php $attributes = $__attributesOriginalc57c361e10a050969f1a9ef52bca9009; ?>
<?php unset($__attributesOriginalc57c361e10a050969f1a9ef52bca9009); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc57c361e10a050969f1a9ef52bca9009)): ?>
<?php $component = $__componentOriginalc57c361e10a050969f1a9ef52bca9009; ?>
<?php unset($__componentOriginalc57c361e10a050969f1a9ef52bca9009); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc57c361e10a050969f1a9ef52bca9009 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc57c361e10a050969f1a9ef52bca9009 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric-card','data' => ['label' => 'Total Orders','value' => '64','change' => '+9.5%','trend' => 'up','icon' => 'shopping-bag']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Total Orders','value' => '64','change' => '+9.5%','trend' => 'up','icon' => 'shopping-bag']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc57c361e10a050969f1a9ef52bca9009)): ?>
<?php $attributes = $__attributesOriginalc57c361e10a050969f1a9ef52bca9009; ?>
<?php unset($__attributesOriginalc57c361e10a050969f1a9ef52bca9009); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc57c361e10a050969f1a9ef52bca9009)): ?>
<?php $component = $__componentOriginalc57c361e10a050969f1a9ef52bca9009; ?>
<?php unset($__componentOriginalc57c361e10a050969f1a9ef52bca9009); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc57c361e10a050969f1a9ef52bca9009 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc57c361e10a050969f1a9ef52bca9009 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric-card','data' => ['label' => 'Est. Profit','value' => '$1,120.00','change' => '+14.0%','trend' => 'up','icon' => 'pie-chart']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Est. Profit','value' => '$1,120.00','change' => '+14.0%','trend' => 'up','icon' => 'pie-chart']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc57c361e10a050969f1a9ef52bca9009)): ?>
<?php $attributes = $__attributesOriginalc57c361e10a050969f1a9ef52bca9009; ?>
<?php unset($__attributesOriginalc57c361e10a050969f1a9ef52bca9009); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc57c361e10a050969f1a9ef52bca9009)): ?>
<?php $component = $__componentOriginalc57c361e10a050969f1a9ef52bca9009; ?>
<?php unset($__componentOriginalc57c361e10a050969f1a9ef52bca9009); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc57c361e10a050969f1a9ef52bca9009 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc57c361e10a050969f1a9ef52bca9009 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.metric-card','data' => ['label' => 'Low Stock Alerts','value' => '3 Items','change' => 'Reorder','trend' => 'down','icon' => 'alert-triangle']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.metric-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Low Stock Alerts','value' => '3 Items','change' => 'Reorder','trend' => 'down','icon' => 'alert-triangle']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc57c361e10a050969f1a9ef52bca9009)): ?>
<?php $attributes = $__attributesOriginalc57c361e10a050969f1a9ef52bca9009; ?>
<?php unset($__attributesOriginalc57c361e10a050969f1a9ef52bca9009); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc57c361e10a050969f1a9ef52bca9009)): ?>
<?php $component = $__componentOriginalc57c361e10a050969f1a9ef52bca9009; ?>
<?php unset($__componentOriginalc57c361e10a050969f1a9ef52bca9009); ?>
<?php endif; ?>
                </div>

                <!-- Chart + Hot Selling Grid -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-3">
                    <div class="lg:col-span-2">
                        <?php if (isset($component)) { $__componentOriginal643ccfe2aae87c3fbab9c1e803e83705 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643ccfe2aae87c3fbab9c1e803e83705 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.sales-chart','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.sales-chart'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643ccfe2aae87c3fbab9c1e803e83705)): ?>
<?php $attributes = $__attributesOriginal643ccfe2aae87c3fbab9c1e803e83705; ?>
<?php unset($__attributesOriginal643ccfe2aae87c3fbab9c1e803e83705); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643ccfe2aae87c3fbab9c1e803e83705)): ?>
<?php $component = $__componentOriginal643ccfe2aae87c3fbab9c1e803e83705; ?>
<?php unset($__componentOriginal643ccfe2aae87c3fbab9c1e803e83705); ?>
<?php endif; ?>
                    </div>
                    <div>
                        <?php if (isset($component)) { $__componentOriginalc8368185f4d69b3c6239645bdea72747 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8368185f4d69b3c6239645bdea72747 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.hot-selling-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.hot-selling-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8368185f4d69b3c6239645bdea72747)): ?>
<?php $attributes = $__attributesOriginalc8368185f4d69b3c6239645bdea72747; ?>
<?php unset($__attributesOriginalc8368185f4d69b3c6239645bdea72747); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8368185f4d69b3c6239645bdea72747)): ?>
<?php $component = $__componentOriginalc8368185f4d69b3c6239645bdea72747; ?>
<?php unset($__componentOriginalc8368185f4d69b3c6239645bdea72747); ?>
<?php endif; ?>
                    </div>
                </div>

                <!-- Dead Stock + Recent Transactions Grid -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-3">
                    <?php if (isset($component)) { $__componentOriginal24ab60a8816ea56d74c98748e0ad2c8a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal24ab60a8816ea56d74c98748e0ad2c8a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.dead-stock-list','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.dead-stock-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal24ab60a8816ea56d74c98748e0ad2c8a)): ?>
<?php $attributes = $__attributesOriginal24ab60a8816ea56d74c98748e0ad2c8a; ?>
<?php unset($__attributesOriginal24ab60a8816ea56d74c98748e0ad2c8a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal24ab60a8816ea56d74c98748e0ad2c8a)): ?>
<?php $component = $__componentOriginal24ab60a8816ea56d74c98748e0ad2c8a; ?>
<?php unset($__componentOriginal24ab60a8816ea56d74c98748e0ad2c8a); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalc1f9866277eda7725d902a97ff2a48a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc1f9866277eda7725d902a97ff2a48a0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.recent-transactions','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.recent-transactions'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc1f9866277eda7725d902a97ff2a48a0)): ?>
<?php $attributes = $__attributesOriginalc1f9866277eda7725d902a97ff2a48a0; ?>
<?php unset($__attributesOriginalc1f9866277eda7725d902a97ff2a48a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1f9866277eda7725d902a97ff2a48a0)): ?>
<?php $component = $__componentOriginalc1f9866277eda7725d902a97ff2a48a0; ?>
<?php unset($__componentOriginalc1f9866277eda7725d902a97ff2a48a0); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\ORVIK Point\ORVIK Store\resources\views/components/dashboard/preview.blade.php ENDPATH**/ ?>